<?php

echo "Can't authenticate $username.  The username and/or password do not match any records.";
echo " ";
echo anchor("welcome/","Return");

?>