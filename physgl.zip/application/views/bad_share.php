<?php


echo "That share tag is invald.  ";
echo anchor("welcome/","Return to PhysGL") . ".";

?>
